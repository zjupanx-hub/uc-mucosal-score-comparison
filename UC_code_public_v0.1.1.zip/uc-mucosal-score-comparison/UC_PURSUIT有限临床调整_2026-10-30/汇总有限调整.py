from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
B=Path(__file__).resolve().parent;T=B/'tables';W=B.parent
assert json.loads((B/'独立数值核对结果.json').read_text(encoding='utf-8'))['pass']
res=pd.read_csv(T/'models53.csv');boot=pd.read_csv(T/'bootstrap30000.csv');loo=pd.read_csv(T/'LOO590.csv');diag=pd.read_csv(T/'joint_diagnostics30.csv')
assert len(res)==53 and res.valid.all() and len(boot)==30000 and len(loo)==590
main=res[res.specification.eq('main59')&res.kind.eq('joint')].copy()
base=res[res.specification.eq('main59')&res.kind.eq('score_clinical')].set_index('score_name')
rr=[]
for r in main.itertuples(index=False):
 b=boot[boot.model_id.eq(r.model_id)];l=loo[loo.model_id.eq(r.model_id)];bv=b[b.valid];lv=l[l.valid]
 assert len(b)==2000 and len(l)==59
 low,high=np.exp(np.quantile(bv.beta,[.025,.975]));dg=diag[diag.model_id.eq(r.model_id)].iloc[0]
 rr.append({'model_id':r.model_id,'score':r.score_name,'bMIS':r.bmis_name,'n':int(r.n),'response_n':int(r.response_n),'OR':r.OR,'Wald_low':r.OR_low,'Wald_high':r.OR_high,'p_Wald':r.p_Wald,'q_Wald_BH10':r.BH_Wald_10,'q_LR_BH10':r.BH_LR_10,'bootstrap_valid':len(bv),'bootstrap_total':len(b),'bootstrap_OR_low':low,'bootstrap_OR_high':high,'bootstrap_positive_fraction':float(bv.beta.gt(0).mean()),'bootstrap_interval_robust':len(bv)>=1900,'LOO_valid':len(lv),'LOO_total':len(l),'LOO_sign_changes':int(np.sum(np.sign(lv.beta)!=np.sign(r.beta))),'LOO_beta_min':float(lv.beta.min()),'LOO_beta_max':float(lv.beta.max()),'LOO_OR_min':float(np.exp(lv.beta.min())),'LOO_OR_max':float(np.exp(lv.beta.max())),'VIF_score':float(dg.VIF_score),'SE_ratio':float(r.SE/base.loc[r.score_name,'SE'])})
summary=pd.DataFrame(rr);summary.to_csv(T/'primary10_with_stability.csv',index=False)
sens=res[res.kind.eq('joint')].copy();sens.to_csv(T/'joint30_sensitivity.csv',index=False)
raw=res[res.specification.eq('main59')&res.kind.isin(['score_only','score_clinical'])].copy();raw.to_csv(T/'original5_before_bMIS.csv',index=False)
u=pd.read_csv(W/'UC最小复跑包与初稿_2026-10-30/package/output/tables/Table2_main_conditional_associations.csv').rename(columns={'评分':'score','bMIS实现':'bMIS','OR':'UNIFI_OR','BH10_q':'UNIFI_q'})
comp=summary.merge(u[['score','bMIS','UNIFI_OR','UNIFI_q']],on=['score','bMIS']);comp['same_conditional_direction']=np.sign(np.log(comp.OR))==np.sign(np.log(comp.UNIFI_OR))
comp.to_csv(T/'UNIFI_PURSUIT_direction_context.csv',index=False)
stats={'n':59,'response_n':32,'nonresponse_n':27,'deterministic_models':53,'all_models_valid':bool(res.valid.all()),'main_Wald_BH10_hits':int(main.BH_Wald_10.lt(.05).sum()),'main_LR_BH10_hits':int(main.BH_LR_10.lt(.05).sum()),'main_min_q_Wald':float(main.BH_Wald_10.min()),'main_min_q_LR':float(main.BH_LR_10.min()),'bootstrap_valid':int(boot.valid.sum()),'bootstrap_total':len(boot),'LOO_valid':int(loo.valid.sum()),'LOO_total':len(loo),'VIF_range':[float(summary.VIF_score.min()),float(summary.VIF_score.max())],'SE_ratio_range':[float(summary.SE_ratio.min()),float(summary.SE_ratio.max())],'same_direction_vs_UNIFI':int(comp.same_conditional_direction.sum()),'comparisons_vs_UNIFI':len(comp),'sensitivity':{},'M4':summary[summary.score.eq('M4')].to_dict('records')}
for spec in ['mayo_only','GOL_reference']:
 x=sens[sens.specification.eq(spec)].set_index(['score_name','bmis_name']);q=main.set_index(['score_name','bmis_name']);x=x.loc[q.index]
 stats['sensitivity'][spec]={'n':len(x),'Wald_BH10_hits':int(x.BH_Wald_10.lt(.05).sum()),'LR_BH10_hits':int(x.BH_LR_10.lt(.05).sum()),'same_direction_as_main':int(np.sum(np.sign(x.beta)==np.sign(q.beta))),'maximum_absolute_beta_shift':float(np.max(np.abs(x.beta-q.beta)))}
stats['sensitivity']['all_joint_BH30_hits']=int(sens.BH_Wald_30.lt(.05).sum())
(B/'结果摘要.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
pd.DataFrame([{'model_id':r.model_id,'valid':bool(r.valid),'has_warning':bool(str(r.warnings)!='nan')} for r in res.itertuples(index=False)]).to_csv(T/'deterministic_fit_status.csv',index=False)
print(summary[['score','bMIS','OR','Wald_low','Wald_high','q_Wald_BH10','bootstrap_OR_low','bootstrap_OR_high','LOO_sign_changes','VIF_score','SE_ratio']].to_string(index=False))
print(json.dumps({k:v for k,v in stats.items() if k!='M4'},ensure_ascii=False))
