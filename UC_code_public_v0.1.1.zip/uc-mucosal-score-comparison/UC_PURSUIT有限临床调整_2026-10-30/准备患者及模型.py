from pathlib import Path
import json,hashlib,sys
import pandas as pd,numpy as np
B=Path(__file__).resolve().parent; W=B.parent
P=W/'UC最小复跑包与初稿_2026-10-30/package'; O=P/'output'
I=B/'inputs';I.mkdir(exist_ok=True);(B/'tables').mkdir(exist_ok=True);(B/'logs').mkdir(exist_ok=True)
F=['strict68_mean','negative_logOR','OSM_mean','M4','M5'];BM=['bMIS_UC_combinedZ','bMIS_UC_GSVA']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
used={}
def rd(rel):
 p=P/rel;used[rel]=sha(p);return pd.read_csv(p,dtype={'patient_id':str})
md=rd('output/data/PURSUIT_all_metadata.csv');sc=rd('output/scores/PURSUIT_all_scores.csv');sub=rd('output/scores/PURSUIT_GOL_only_scores.csv')
assert md.patient_id.is_unique and md.gsm.is_unique and sc.patient_id.is_unique and sub.patient_id.is_unique
assert len(md)==len(sc)==87 and len(sub)==59 and set(md.patient_id)==set(sc.patient_id)
g=md[md.treatment.str.lower().eq('golimumab')].set_index('patient_id').sort_index()
assert len(g)==59 and g.visit.eq('Week 0').all() and g.wk6response.isin(['Yes','No']).all()
assert set(g.index)==set(sub.patient_id)
s=sc.set_index('patient_id').loc[g.index,F+BM];sub=sub.set_index('patient_id').loc[g.index,BM]
d=pd.DataFrame(index=g.index);d['gsm']=g.gsm;d['nonresponse']=g.wk6response.eq('No').astype(int)
d['age_raw']=pd.to_numeric(g.age,errors='raise');d['Mayo_raw']=pd.to_numeric(g['mayo score'],errors='raise')
assert d.notna().all().all() and int(d.nonresponse.sum())==27
assert d.age_raw.between(18,100).all() and d.Mayo_raw.between(0,12).all()
d['age10']=(d.age_raw-d.age_raw.mean())/10;d['Mayo']=d.Mayo_raw-d.Mayo_raw.mean()
scales=[]
for f in F+BM:
 x=s[f];mu=x.mean();sd=x.std(ddof=1);assert sd>0 and np.isfinite(x).all()
 d[f]=(x-mu)/sd;scales.append({'feature':f,'reference':'all87','mean':mu,'sample_SD':sd})
ref=d.copy()
for f in BM:
 x=sub[f];mu=x.mean();sd=x.std(ddof=1);assert sd>0 and np.isfinite(x).all()
 ref[f]=(x-mu)/sd;scales.append({'feature':f,'reference':'GOL59','mean':mu,'sample_SD':sd})
d.to_csv(I/'main59.csv');ref.to_csv(I/'GOL_reference59.csv');pd.DataFrame(scales).to_csv(I/'fixed_model_scales.csv',index=False)
mf=[]
def add(spec,kind,score='',bmis='',null=''):
 mid='__'.join([spec,kind,score or 'none',bmis or 'none'])
 v=(['score'] if score else [])+(['bmis'] if bmis else [])+([] if kind=='score_only' else ['Mayo'] if spec=='mayo_only' else ['age10','Mayo'])
 mf.append({'model_id':mid,'specification':spec,'kind':kind,'score_name':score,'bmis_name':bmis,'input_file':'GOL_reference59.csv' if spec=='GOL_reference' else 'main59.csv','variables':';'.join(v),'null_id':null});return mid
for spec in ['main59','mayo_only','GOL_reference']:
 if spec!='GOL_reference':
  add(spec,'clinical')
  if spec=='main59':
   for f in F:add(spec,'score_only',f)
  for f in F:add(spec,'score_clinical',f)
 for bm in BM:
  null=add(spec,'bmis_clinical',bmis=bm)
  for f in F:add(spec,'joint',f,bm,null)
assert len(mf)==53
pd.DataFrame(mf).to_csv(I/'model_manifest.csv',index=False)
dump(B/'患者及输入核查.json',{'baseline_reference_n':87,'treated_n':59,'responders':32,'nonresponders':27,'all_age_Mayo_complete':True,'unique_patient_GSM':True,'age_range':[int(d.age_raw.min()),int(d.age_raw.max())],'Mayo_range':[float(d.Mayo_raw.min()),float(d.Mayo_raw.max())],'models':53,'primary_joint_models':10,'score_direction':'adverse fixed','score_reference':'all87, with paired GOL59 bMIS sensitivity','source_sha256':used})
plan=B/'固定分析方案.md';(B/'方案SHA256.txt').write_text(sha(plan)+'  固定分析方案.md\n',encoding='utf-8')
dump(B/'分析前冻结.json',{'plan_sha256':sha(plan),'manifest_sha256':sha(I/'model_manifest.csv'),'main59_sha256':sha(I/'main59.csv'),'GOL_reference59_sha256':sha(I/'GOL_reference59.csv'),'outcomes_previously_seen':True,'new_regression_results_read_before_freeze':False})
print(json.dumps({'n':59,'responders':32,'nonresponders':27,'models':53,'plan_sha256':sha(plan)},ensure_ascii=False))
