Sys.setlocale('LC_ALL','English_United States.utf8')
options(stringsAsFactors=FALSE)
B<-normalizePath(commandArgs(trailingOnly=TRUE)[1],winslash='/',mustWork=TRUE)
I<-file.path(B,'inputs');T<-file.path(B,'tables');mf<-read.csv(file.path(I,'model_manifest.csv'),check.names=FALSE,na.strings='');mf[is.na(mf)]<-''
make_data<-function(r){d<-read.csv(file.path(I,r$input_file),check.names=FALSE);if(nzchar(r$score_name))d$score<-d[[r$score_name]];if(nzchar(r$bmis_name))d$bmis<-d[[r$bmis_name]];d}
fit_one<-function(d,v){
 w<-character();f<-withCallingHandlers(glm(reformulate(v,response='nonresponse'),data=d,family=binomial(),control=glm.control(epsilon=1e-12,maxit=100)),warning=function(x){w<<-c(w,conditionMessage(x));invokeRestart('muffleWarning')})
 tab<-coef(summary(f));p<-fitted(f);valid<-isTRUE(f$converged)&&!isTRUE(f$boundary)&&f$rank==ncol(model.matrix(f))&&all(is.finite(tab))&&all(p>1e-8&p<1-1e-8)
 list(fit=f,valid=valid,warnings=paste(w,collapse=' | '))
}
rr<-list();allc<-list();dg<-list()
for(i in seq_len(nrow(mf))){
 r<-mf[i,];d<-make_data(r);v<-strsplit(r$variables,';',fixed=TRUE)[[1]];a<-fit_one(d,v);f<-a$fit;tab<-coef(summary(f));target<-if(nzchar(r$score_name))'score' else if(nzchar(r$bmis_name))'bmis' else 'Mayo';z<-tab[target,];p<-fitted(f)
 rr[[i]]<-data.frame(model_id=r$model_id,specification=r$specification,kind=r$kind,score_name=r$score_name,bmis_name=r$bmis_name,n=nrow(d),response_n=sum(d$nonresponse==0),target=target,beta=z[1],SE=z[2],OR=exp(z[1]),OR_low=exp(z[1]-qnorm(.975)*z[2]),OR_high=exp(z[1]+qnorm(.975)*z[2]),p_Wald=z[4],logLik=as.numeric(logLik(f)),rank=f$rank,parameters=ncol(model.matrix(f)),converged=f$converged,valid=a$valid,min_probability=min(p),max_probability=max(p),max_Cook=max(cooks.distance(f)),warnings=a$warnings)
 allc[[i]]<-data.frame(model_id=r$model_id,term=rownames(tab),beta=tab[,1],SE=tab[,2],p=tab[,4])
 if(r$kind=='joint'){
  X<-model.matrix(f)[,-1,drop=FALSE];xx<-cbind(1,X[,colnames(X)!='score',drop=FALSE]);y<-X[,'score'];vif<-sum((y-mean(y))^2)/sum(lm.fit(xx,y)$residuals^2)
  dg[[length(dg)+1]]<-data.frame(model_id=r$model_id,VIF_score=vif,max_leverage=max(hatvalues(f)),score_bmis_Pearson=cor(d$score,d$bmis),score_bmis_Spearman=cor(d$score,d$bmis,method='spearman'))
 }
}
res<-do.call(rbind,rr);res$LR_chisq<-res$p_LR<-res$BH_Wald_10<-res$BH_LR_10<-res$BH_Wald_30<-res$BH_clinical_5<-NA_real_
for(i in which(mf$kind=='joint')){r<-mf[i,];j<-match(r$null_id,res$model_id);s<-2*(res$logLik[i]-res$logLik[j]);stopifnot(s>=-1e-8);res$LR_chisq[i]<-max(0,s);res$p_LR[i]<-pchisq(max(0,s),1,lower.tail=FALSE)}
for(spec in unique(mf$specification)){
 k<-res$specification==spec&res$kind=='joint';stopifnot(sum(k)==10);res$BH_Wald_10[k]<-p.adjust(res$p_Wald[k],'BH');res$BH_LR_10[k]<-p.adjust(res$p_LR[k],'BH')
 k<-res$specification==spec&res$kind=='score_clinical';if(any(k))res$BH_clinical_5[k]<-p.adjust(res$p_Wald[k],'BH')
}
k<-res$kind=='joint';res$BH_Wald_30[k]<-p.adjust(res$p_Wald[k],'BH')
write.csv(res,file.path(T,'models53.csv'),row.names=FALSE);write.csv(do.call(rbind,allc),file.path(T,'all_coefficients.csv'),row.names=FALSE);write.csv(do.call(rbind,dg),file.path(T,'joint_diagnostics30.csv'),row.names=FALSE)
cat('DETERMINISTIC_COMPLETE',nrow(res),'valid',sum(res$valid),'\n');flush.console();stopifnot(all(res$valid))
d<-read.csv(file.path(I,'main59.csv'),check.names=FALSE);set.seed(20261030);NB<-2000L
ix<-t(replicate(NB,c(sample(which(d$nonresponse==0),sum(d$nonresponse==0),replace=TRUE),sample(which(d$nonresponse==1),sum(d$nonresponse==1),replace=TRUE))))
write.csv(ix,file.path(I,'bootstrap2000_indices_1based.csv'),row.names=FALSE)
bmf<-mf[mf$specification=='main59'&mf$kind%in%c('joint','score_clinical'),];boot<-vector('list',NB*nrow(bmf));q<-0L
for(k in seq_len(NB)){
 dd<-d[ix[k,],,drop=FALSE]
 for(j in seq_len(nrow(bmf))){
  r<-bmf[j,];dd$score<-dd[[r$score_name]];if(nzchar(r$bmis_name))dd$bmis<-dd[[r$bmis_name]]
  a<-tryCatch(fit_one(dd,strsplit(r$variables,';',fixed=TRUE)[[1]]),error=function(e)list(valid=FALSE,warnings=conditionMessage(e)));q<-q+1L
  if(!is.null(a$fit)){z<-coef(summary(a$fit))['score',];boot[[q]]<-data.frame(draw=k,model_id=r$model_id,beta=z[1],SE=z[2],valid=a$valid,warnings=a$warnings)}else boot[[q]]<-data.frame(draw=k,model_id=r$model_id,beta=NA_real_,SE=NA_real_,valid=FALSE,warnings=a$warnings)
 }
 if(k%%200L==0L){cat('BOOTSTRAP',k,'/',NB,'\n');flush.console()}
}
boot<-do.call(rbind,boot);write.csv(boot,file.path(T,'bootstrap30000.csv'),row.names=FALSE)
lmf<-mf[mf$specification=='main59'&mf$kind=='joint',];loo<-vector('list',59L*nrow(lmf));q<-0L
for(k in seq_len(nrow(d))){
 dd<-d[-k,,drop=FALSE]
 for(j in seq_len(nrow(lmf))){r<-lmf[j,];dd$score<-dd[[r$score_name]];dd$bmis<-dd[[r$bmis_name]];a<-tryCatch(fit_one(dd,strsplit(r$variables,';',fixed=TRUE)[[1]]),error=function(e)list(valid=FALSE,warnings=conditionMessage(e)));q<-q+1L
 if(!is.null(a$fit)){z<-coef(summary(a$fit))['score',];loo[[q]]<-data.frame(omitted_patient=d$patient_id[k],model_id=r$model_id,beta=z[1],SE=z[2],valid=a$valid,warnings=a$warnings)}else loo[[q]]<-data.frame(omitted_patient=d$patient_id[k],model_id=r$model_id,beta=NA_real_,SE=NA_real_,valid=FALSE,warnings=a$warnings)}
}
loo<-do.call(rbind,loo);write.csv(loo,file.path(T,'LOO590.csv'),row.names=FALSE)
capture.output(sessionInfo(),file=file.path(B,'R_sessionInfo.txt'))
cat('COMPLETE bootstrap_valid',sum(boot$valid),'/',nrow(boot),'LOO_valid',sum(loo$valid),'/',nrow(loo),'\n')
