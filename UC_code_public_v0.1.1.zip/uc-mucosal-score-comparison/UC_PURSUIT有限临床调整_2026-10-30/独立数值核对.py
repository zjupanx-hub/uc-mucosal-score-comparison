from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
from scipy.special import expit
from scipy.optimize import minimize
from scipy.stats import norm,chi2,false_discovery_control
B=Path(__file__).resolve().parent; W=B.parent;P=W/'UC最小复跑包与初稿_2026-10-30/package/output'
frozen=json.loads((B/'分析前冻结.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(B/'固定分析方案.md')==frozen['plan_sha256']
assert sha(B/'inputs/model_manifest.csv')==frozen['manifest_sha256']
md=pd.read_csv(P/'data/PURSUIT_all_metadata.csv',dtype={'patient_id':str}).set_index('patient_id')
sc=pd.read_csv(P/'scores/PURSUIT_all_scores.csv',dtype={'patient_id':str}).set_index('patient_id')
sub=pd.read_csv(P/'scores/PURSUIT_GOL_only_scores.csv',dtype={'patient_id':str}).set_index('patient_id')
g=md[md.treatment.str.lower().eq('golimumab')].sort_index();ids=g.index;y=g.wk6response.eq('No').to_numpy(dtype=float)
assert len(ids)==59 and y.sum()==27
mf=pd.read_csv(B/'inputs/model_manifest.csv').fillna('');res=pd.read_csv(B/'tables/models53.csv').set_index('model_id')
fits={};rows=[];optimizer_notes=[]
for r in mf.itertuples(index=False):
    values={'age10':(g.age.to_numpy(float)-g.age.to_numpy(float).mean())/10,'Mayo':g['mayo score'].to_numpy(float)-g['mayo score'].to_numpy(float).mean()}
    if r.score_name:
        z=sc.loc[ids,r.score_name].to_numpy(float);values['score']=(z-z.mean())/z.std(ddof=1)
    if r.bmis_name:
        z=(sub if r.specification=='GOL_reference' else sc).loc[ids,r.bmis_name].to_numpy(float);values['bmis']=(z-z.mean())/z.std(ddof=1)
    vars=r.variables.split(';');X=np.column_stack([np.ones(len(y))]+[values[v] for v in vars])
    def obj(b):
        z=X@b;return np.logaddexp(0,z).sum()-y@z
    def grad(b):return X.T@(expit(X@b)-y)
    def hess(b):
        p=expit(X@b);return X.T@((p*(1-p))[:,None]*X)
    o=minimize(obj,np.zeros(X.shape[1]),jac=grad,hess=hess,method='trust-exact',options={'gtol':1e-10,'maxiter':300})
    before=float(np.linalg.norm(grad(o.x),ord=np.inf));start_fun=float(obj(o.x))
    # Newton refinement of the same analytic likelihood near machine-precision
    # objective changes; retain all original verification tolerances.
    steps=0
    while np.linalg.norm(grad(o.x),ord=np.inf)>1e-10 and steps<5:
        candidate=o.x-np.linalg.solve(hess(o.x),grad(o.x))
        if np.linalg.norm(grad(candidate),ord=np.inf)>=np.linalg.norm(grad(o.x),ord=np.inf):break
        assert obj(candidate)<=start_fun+1e-10
        o.x=candidate;steps+=1
    o.fun=obj(o.x)
    optimizer_notes.append({'model_id':r.model_id,'optimizer_success_flag':bool(o.success),'message':str(o.message),'gradient_before':before,'gradient_after':float(np.linalg.norm(grad(o.x),ord=np.inf)),'Newton_refinement_steps':steps,'objective_change':float(o.fun-start_fun)})
    assert np.linalg.norm(grad(o.x),ord=np.inf)<1e-7,(r.model_id,o.message)
    se=np.sqrt(np.diag(np.linalg.inv(hess(o.x))));target='score' if r.score_name else 'bmis' if r.bmis_name else 'Mayo';k=1+vars.index(target)
    rw={'model_id':r.model_id,'beta_python':o.x[k],'SE_python':se[k],'logLik_python':-o.fun,'p_Wald_python':2*norm.sf(abs(o.x[k]/se[k]))}
    fits[r.model_id]={'logLik':-o.fun};rows.append(rw)
d=pd.DataFrame(rows).set_index('model_id')
errs={k:float(np.max(np.abs(d[k+'_python']-res.loc[d.index,k]))) for k in ['beta','SE','logLik','p_Wald']}
assert errs['beta']<1e-6 and errs['SE']<1e-6 and errs['logLik']<1e-7 and errs['p_Wald']<1e-6,errs
for r in mf[mf.kind.eq('joint')].itertuples(index=False):
    stat=max(0,2*(fits[r.model_id]['logLik']-fits[r.null_id]['logLik']));d.loc[r.model_id,'p_LR_python']=chi2.sf(stat,1)
for spec in mf.specification.unique():
    ix=mf.loc[mf.specification.eq(spec)&mf.kind.eq('joint'),'model_id']
    for p,k in [('p_Wald_python','BH_Wald_10'),('p_LR_python','BH_LR_10')]:
        val=false_discovery_control(d.loc[ix,p].to_numpy());d.loc[ix,k+'_python']=val
        errs[spec+'_'+k]=float(np.max(np.abs(val-res.loc[ix,k].to_numpy())))
joint=mf.loc[mf.kind.eq('joint'),'model_id'];errs['p_LR']=float(np.max(np.abs(d.loc[joint,'p_LR_python']-res.loc[joint,'p_LR'])))
q30=false_discovery_control(d.loc[joint,'p_Wald_python'].to_numpy());d.loc[joint,'BH_Wald_30_python']=q30
errs['BH_Wald_30']=float(np.max(np.abs(q30-res.loc[joint,'BH_Wald_30'].to_numpy())))
for spec in ['main59','mayo_only']:
    ix=mf.loc[mf.specification.eq(spec)&mf.kind.eq('score_clinical'),'model_id'];v=false_discovery_control(d.loc[ix,'p_Wald_python'].to_numpy())
    errs[spec+'_BH_clinical_5']=float(np.max(np.abs(v-res.loc[ix,'BH_clinical_5'].to_numpy())))
assert max(v for k,v in errs.items() if k not in ['beta','SE','logLik'])<1e-6,errs
d.reset_index().to_csv(B/'tables/Python_independent53.csv',index=False)
(B/'独立优化器诊断.json').write_text(json.dumps({'initial_check':'The first trust-exact fit stopped near the optimum with gradient 1.9118e-7 and machine-precision objective changes; diagnostic Newton step reduced the gradient without changing likelihood. Original comparison and residual tolerances retained.','models':optimizer_notes},ensure_ascii=False,indent=2),encoding='utf-8')
(B/'独立数值核对结果.json').write_text(json.dumps({'pass':True,'method':'Independent SciPy likelihood optimization from original patient metadata and frozen score files, not R design input','models':53,'max_abs_errors':errs,'plan_unchanged':True},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'pass':True,'models':53,'max_abs_errors':errs},ensure_ascii=False))
