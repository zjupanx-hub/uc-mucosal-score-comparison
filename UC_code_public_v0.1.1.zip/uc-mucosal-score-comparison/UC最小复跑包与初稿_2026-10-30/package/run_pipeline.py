from pathlib import Path
import sys,os,argparse,subprocess,time,json,hashlib
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['all','scores','statistics','regression','figures','validate'],default='all');ap.add_argument('--rscript',default='Rscript');args=ap.parse_args()
assert sys.prefix!=sys.base_prefix,'Use a clean virtual environment'
out=P/'output';out.mkdir(exist_ok=True);logs=out/'logs';logs.mkdir(exist_ok=True)
env=os.environ.copy();tmp=out/'tmp';tmp.mkdir(exist_ok=True);env.update(TEMP=str(tmp),TMP=str(tmp),PYTHONUTF8='1',MPLCONFIGDIR=str(out/'mpl_cache'),R_LIBS_USER=str(out/'empty_R_library'))
for k in ['PYTHONPATH','PYTHONHOME','OPENAI_API_KEY']:env.pop(k,None)
stages=['scores','statistics','regression','figures','validate'] if args.stage=='all' else [args.stage]
if args.stage=='all' and (out/'scores_complete.json').exists():raise SystemExit('Full run refuses existing score cache; use a new package/output for a new clean run')
records=[]
for stage in stages:
 name={'scores':'compute_scores.py','statistics':'compute_statistics.py','figures':'render_figures.py','validate':'validate.py'}.get(stage)
 if stage=='regression':cmd=[args.rscript,'--vanilla',str(P/'src/run_regression.R'),str(P)]
 else:
  code="import sys,runpy;sys.path.insert(0,"+repr(str(P/'src'))+");runpy.run_path("+repr(str(P/'src'/name))+",run_name='__main__')"
  cmd=[sys.executable,'-I','-X','utf8','-c',code]
 start=time.time();print('STAGE_START',stage,flush=True)
 with (logs/(stage+'.log')).open('w',encoding='utf-8') as f:
  pr=subprocess.Popen(cmd,cwd=P,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
  for line in pr.stdout:f.write(line);f.flush();print(line,end='',flush=True)
  code=pr.wait()
 rec={'stage':stage,'returncode':code,'seconds':time.time()-start,'command':cmd};records.append(rec)
 (out/('run_receipt_'+args.stage+'.json')).write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
 if code:raise SystemExit(code)
 print('STAGE_PASS',stage,flush=True)
