param([string]$PythonExe='python',[string]$RscriptExe='Rscript',[switch]$EnvironmentOnly)
$ErrorActionPreference='Stop'
$packageRoot=$PSScriptRoot
$tempRoot=Join-Path $packageRoot 'setup_tmp'
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
$env:TEMP=$tempRoot
$env:TMP=$tempRoot
$env:PYTHONUTF8='1'
& $PythonExe -X utf8 -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,12) else 2)"
if($LASTEXITCODE -ne 0){throw 'Python 3.12 is required for the supplied Windows wheels'}
$venvDir=Join-Path $packageRoot '.venv'
if(-not (Test-Path -LiteralPath (Join-Path $venvDir 'Scripts/python.exe'))){
 & $PythonExe -X utf8 -m venv --copies --without-pip $venvDir
 if($LASTEXITCODE -ne 0){throw 'Virtual environment creation failed'}
}
$venvPython=Join-Path $venvDir 'Scripts/python.exe'
& $venvPython -X utf8 -m ensurepip --upgrade --default-pip
if($LASTEXITCODE -ne 0){throw 'ensurepip failed'}
& $venvPython -X utf8 -m pip --isolated install --no-index --find-links (Join-Path $packageRoot 'wheels') --require-hashes -r (Join-Path $packageRoot 'requirements_windows_hashes.txt')
if($LASTEXITCODE -ne 0){throw 'Locked dependency installation failed'}
if($EnvironmentOnly){Write-Output 'OFFLINE_HASH_LOCKED_ENVIRONMENT_PASS';return}
& $venvPython -I -X utf8 (Join-Path $packageRoot 'run_pipeline.py') --stage all --rscript $RscriptExe
if($LASTEXITCODE -ne 0){throw 'Pipeline or acceptance did not pass; inspect output/logs and validation.json'}
