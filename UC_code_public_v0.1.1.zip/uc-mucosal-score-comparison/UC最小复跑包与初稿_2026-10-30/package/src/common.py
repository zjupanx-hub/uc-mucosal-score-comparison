from pathlib import Path
import hashlib,json,os,sys,time
P=Path(__file__).resolve().parent.parent
O=P/'output';O.mkdir(exist_ok=True)
F=['strict68_mean','negative_logOR','OSM_mean','M4','M5']
BM=['bMIS_UC_combinedZ','bMIS_UC_GSVA']
SEED=20261030;NB=2000
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def js(path,obj):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def inp(rel):
 assert rel.startswith('input/'),rel
 p=P/rel;entry=next(x for x in json.loads((P/'input_manifest.json').read_text(encoding='utf-8')) if x['path']==rel)
 assert sha(p)==entry['sha256'],rel
 return p
def runtime(stage):
 import importlib.metadata as md
 assert sys.prefix!=sys.base_prefix,'Run in a new virtual environment'
 assert not any('.preanalysis_deps' in x or '.uc_pilot_deps' in x for x in sys.path)
 pins={line.split('==')[0]:line.split('==')[1] for line in (P/'requirements.lock.txt').read_text().splitlines() if line.strip()}
 assert all(md.version(k)==v for k,v in pins.items())
 js(O/(stage+'_runtime.json'),{'stage':stage,'python':sys.version,'executable':sys.executable,'prefix':sys.prefix,'sys_path':sys.path,'versions':pins,'start_unix':time.time(),'code_sha256':sha(Path(sys.argv[0]).resolve()),'reference_read_for_computation':False})
os.environ['MPLCONFIGDIR']=str(O/'mpl_cache')
