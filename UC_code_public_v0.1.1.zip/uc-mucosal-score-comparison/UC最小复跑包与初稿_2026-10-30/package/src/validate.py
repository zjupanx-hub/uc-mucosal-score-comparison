import json
import pandas as pd,numpy as np
from common import *
runtime('validation')
if not (O/'tables/outcomes144.csv').exists():
 js(O/'empty_output_rejection.json',{'pass':False,'reason':'Missing newly computed outcomes; historical reference files cannot satisfy acceptance'})
 raise SystemExit(2)
checks=[]
def comp(name,a,b,keys,cols,tol):
 assert not a.duplicated(keys).any() and not b.duplicated(keys).any(),name
 d=a.merge(b,on=keys,suffixes=('_new','_expected'),how='outer',indicator=True,validate='one_to_one')
 same=d['_merge'].eq('both').all();err={}
 for col in cols:
  x=pd.to_numeric(d[col+'_new'],errors='coerce').to_numpy();y=pd.to_numeric(d[col+'_expected'],errors='coerce').to_numpy()
  err[col]=float(np.nanmax(abs(x-y))) if np.isfinite(x-y).any() else 0.
  same=same and np.array_equal(np.isnan(x),np.isnan(y))
 ok=bool(same and all(v<=tol for v in err.values()));checks.append({'check':name,'rows':len(d),'max_errors':err,'tolerance':tol,'pass':ok})
 if not ok:d.to_csv(O/('mismatch_'+name+'.csv'),index=False)
old=pd.read_csv(P/'reference/patient_scores_and_outcomes.csv');old['trial']=old.dataset.map(lambda s:'UNIFI_all_UC' if s.startswith('UNIFI') else 'PURSUIT_all' if s.startswith('PURSUIT') else 'PROgECT')
expect=old.groupby(['trial','patient_id','feature'],as_index=False).score.first();assert old.groupby(['trial','patient_id','feature']).score.nunique().eq(1).all()
actual=[]
for ref in ['UNIFI_all_UC','PROgECT','PURSUIT_all']:
 d=pd.read_csv(O/'scores'/(ref+'_scores.csv'));d=d.melt(id_vars='patient_id',var_name='feature',value_name='score');d['trial']=ref;actual.append(d)
comp('patient_scores12978',pd.concat(actual),expect,['trial','patient_id','feature'],['score'],1e-8)
new=pd.read_csv(O/'tables/outcomes144.csv');expected=pd.read_csv(P/'reference/outcomes144.csv')
cols=['n','response_n','nonresponse_n','AUC','AUC_low','AUC_high','p_two_sided','BH_q_primary_PROgECT_3','BH_q_primary_2','BH_q_primary_5','BH_q_all_MARS_88','BH_q_primary_MARS_33','BH_q_bMIS_all16','BH_q_bMIS_primary6']
comp('outcomes144',new,expected,['dataset','endpoint','feature'],cols,1e-10)
comp('rank_structure',pd.read_csv(O/'tables/rank_structure.csv'),pd.read_csv(P/'reference/rank_structure.csv'),['cohort'],['median_pair_rho','rank_PC1_fraction'],1e-12)
clinical=[]
for fn,rename in [
 ('clinical_original5.csv',{'score':'feature','inflammation_measure':'measure','Spearman_rho':'rho','BH_q_25':'BH_within_family'}),
 ('clinical_MARS.csv',{'pathway':'feature','BH_q_55':'BH_within_family'}),
 ('clinical_bMIS.csv',{'implementation':'feature','BH_q_10':'BH_within_family'})]:
 clinical.append(pd.read_csv(P/'reference'/fn).rename(columns=rename))
comp('clinical_correlations90',pd.read_csv(O/'tables/clinical_correlations90.csv'),pd.concat(clinical),['feature','measure'],['n','rho','p_two_sided','BH_within_family'],1e-12)
cor=pd.read_csv(O/'tables/correlations459.csv')
def pairs(d,a,b,rho):
 d=d.rename(columns={rho:'rho'}).copy();d['pair_key']=[';'.join(sorted([x,y])) for x,y in zip(d[a],d[b])]
 return d[['cohort','pair_key','rho','CI_low','CI_high']]
c=pairs(cor,'score1','score2','rho')
for label,fn,a,b,rho in [('old5','original5_correlations.csv','score1','score2','Spearman_rho'),('MARS','MARS_correlations.csv','pathway','old_score','rho'),('bMIS','bMIS_correlations.csv','bMIS_implementation','other_feature','rho')]:
 e=pairs(pd.read_csv(P/'reference'/fn),a,b,rho);q=c.merge(e[['cohort','pair_key']],on=['cohort','pair_key'],validate='one_to_one');comp('correlations_'+label,q,e,['cohort','pair_key'],['rho','CI_low','CI_high'],1e-12)
for label,fn,keys,cols,tol in [
 ('regression66','regression66.csv',['model_id'],['n','remission_n','beta','SE','OR','OR_low','OR_high','p_Wald','logLik','p_LR','BH_Wald_10','BH_LR_10','BH_Wald_40'],1e-6),
 ('coefficients403','regression_coefficients403.csv',['model_id','term'],['beta','SE','p'],1e-6),
 ('bootstrap30000','bootstrap30000.csv',['draw','model_id'],['beta','SE'],1e-6),
 ('LOO3640','LOO3640.csv',['omitted_patient','model_id'],['beta','SE'],1e-6)]:
 nf={'regression66.csv':'全部66模型.csv','regression_coefficients403.csv':'全部回归系数.csv','bootstrap30000.csv':'bootstrap全部30000次拟合.csv','LOO3640.csv':'留一患者全部3640次拟合.csv'}[fn]
 comp(label,pd.read_csv(O/'regression'/nf),pd.read_csv(P/'reference'/fn),keys,cols,tol)
formula=json.loads((O/'GSVA_formula_checks.json').read_text());checks.append({'check':'independent_GSVA_1014_values','rows':sum(x['fixed_targets']*x['gene_sets'] for x in formula),'pass':len(formula)==6 and sum(x['fixed_targets']*x['gene_sets'] for x in formula)==1014 and all(x['pass'] for x in formula)})
checks.append({'check':'five_main_figures_exist','pass':all((O/'figures'/f'Figure{i}.{ext}').is_file() for i in range(1,6) for ext in ['png','pdf','svg'])})
tab1=pd.read_csv(O/'tables/Table1_cohort_and_main_results.csv');tab2=pd.read_csv(O/'tables/Table2_main_conditional_associations.csv')
checks.append({'check':'two_main_tables_generated','pass':bool(len(tab1)==3 and tab1['基线参照人数'].sum()==721 and tab1['主要用药人数'].sum()==507 and len(tab2)==10 and tab2['BH10_q'].ge(.05).all())})
out={'pass':all(c['pass'] for c in checks),'checks':checks,'reference_used_only_here':True,'scope':'Current standalone pipeline from processed expression to scores, outcomes, correlations and UNIFI association/stability; historical technical estimates rendered only'}
js(O/'validation.json',out);print(json.dumps(out,ensure_ascii=False,indent=2),flush=True)
if not out['pass']:raise SystemExit(1)
