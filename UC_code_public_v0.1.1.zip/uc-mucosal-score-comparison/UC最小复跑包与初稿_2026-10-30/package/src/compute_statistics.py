import json,itertools
import numpy as np,pandas as pd
from scipy import stats
from common import *
runtime('statistics');assert (O/'scores_complete.json').exists()
T=O/'tables';T.mkdir(exist_ok=True);R=O/'regression_inputs';R.mkdir(exist_ok=True)
PTH=list(json.loads(inp('input/recipes/MARS_v7.4.json').read_text(encoding='utf-8')))
ALL=F+PTH+BM
scores={n:pd.read_csv(O/'scores'/(n+'_scores.csv'),index_col=0) for n in ['UNIFI_all_UC','PROgECT','PURSUIT_all']}
md={n:pd.read_csv(O/'data'/(n+'_metadata.csv'),index_col=0,keep_default_na=False).set_index('patient_id',drop=False) for n in scores}
primary={('UNIFI_UST','W8_clinical_remission'),('PROgECT','W6_clinical_remission'),('PURSUIT_GOL','W6_clinical_response')}
slices=[]
for ref,clinical in md.items():
 if ref=='UNIFI_all_UC':
  for arm in ['UST','Placebo']:
   g=clinical[clinical.treatment.str.startswith('Ustekinumab') if arm=='UST' else clinical.treatment.str.startswith('Placebo')]
   for ep,col in [('W8_clinical_remission','clinical remission at week 8'),('W8_HEMH_original_label','mucosal healing at week 8')]:
    q=g[g[col].isin(['Y','N'])];slices.append(('UNIFI_'+arm,ep,ref,q.index,q[col].eq('N').astype(int)))
 elif ref=='PROgECT':
  for ep,col in [('W6_clinical_remission','clinical remission at week 6'),('W6_MH_original_label','mucosal healing at week 6')]:
   q=clinical[clinical[col].isin(['Y','N'])];slices.append(('PROgECT',ep,ref,q.index,q[col].eq('N').astype(int)))
 else:
  for arm in ['GOL','Placebo']:
   q=clinical[clinical.treatment.str.lower().eq('golimumab') if arm=='GOL' else clinical.treatment.str.lower().eq('placebo')]
   assert q.wk6response.isin(['Yes','No']).all();slices.append(('PURSUIT_'+arm,'W6_clinical_response',ref,q.index,q.wk6response.eq('No').astype(int)))
def auc(y,x):
 rk=stats.rankdata(x,axis=0);n1=y.sum();n0=len(y)-n1
 return ((rk*y[:,None]).sum(axis=0)-n1*(n1+1)/2)/(n1*n0)
def bootauc(y,x,ix):
 out=np.empty((len(ix),x.shape[1]))
 for start in range(0,len(ix),64):
  end=min(start+64,len(ix));yy=y[ix[start:end]];rk=stats.rankdata(x[ix[start:end]],axis=1);n1=yy.sum(axis=1);n0=len(y)-n1
  out[start:end]=((rk*yy[:,:,None]).sum(axis=1)-n1[:,None]*(n1[:,None]+1)/2)/(n1*n0)[:,None]
 return out
rows=[];long=[];pairs=[];sens=[]
for dataset,endpoint,ref,ids,yy in sorted(slices,key=lambda z:(z[0],z[1])):
 d=scores[ref].loc[ids,ALL].sort_index();y=yy.loc[d.index].to_numpy(dtype=int);x=d.to_numpy();n1=int(y.sum());n0=len(y)-n1
 au=auc(y,x);rng=np.random.default_rng(SEED);ix=np.concatenate([rng.choice(np.flatnonzero(y==v),(NB,int((y==v).sum())),replace=True) for v in [0,1]],axis=1);ba=bootauc(y,x,ix)
 for j,f in enumerate(ALL):
  low,high=np.quantile(ba[:,j],[.025,.975]);pv=stats.mannwhitneyu(d.loc[y==1,f],d.loc[y==0,f],alternative='two-sided',method='asymptotic').pvalue
  group='original5' if f in F else 'bMIS' if f in BM else 'MARS'
  rows.append({'dataset':dataset,'endpoint':endpoint,'is_primary_slice':(dataset,endpoint) in primary,'score_group':group,'feature':f,'n':len(y),'nonresponse_n':n1,'response_n':n0,'AUC':au[j],'AUC_low':low,'AUC_high':high,'p_two_sided':pv})
  long.extend({'dataset':dataset,'endpoint':endpoint,'patient_id':pid,'feature':f,'nonresponse':int(v),'score':float(s)} for pid,v,s in zip(d.index,y,d[f]))
 if (dataset,endpoint) in primary:
  for new in PTH+BM:
   targets=F if new in PTH else F+PTH
   for old in targets:
    j,k=ALL.index(new),ALL.index(old);low,high=np.quantile(ba[:,j]-ba[:,k],[.025,.975]);pairs.append({'dataset':dataset,'endpoint':endpoint,'new_feature':new,'old_feature':old,'delta_AUC':au[j]-au[k],'CI_low':low,'CI_high':high})
 if dataset in ['UNIFI_UST','PURSUIT_GOL'] and (dataset,endpoint) in primary:
  name='UNIFI_UST_only' if dataset=='UNIFI_UST' else 'PURSUIT_GOL_only';sub=pd.read_csv(O/'scores'/(name+'_scores.csv'),index_col=0).loc[d.index,PTH+BM]
  ab=auc(y,sub.to_numpy());bb=bootauc(y,sub.to_numpy(),ix)
  for j,f in enumerate(sub.columns):
   k=ALL.index(f);low,high=np.quantile(bb[:,j]-ba[:,k],[.025,.975]);sens.append({'dataset':dataset,'feature':f,'AUC_main_reference':au[k],'AUC_subset_reference':ab[j],'delta_AUC':ab[j]-au[k],'CI_low':low,'CI_high':high})
 print('OUTCOME_DONE',dataset,endpoint,len(d),n0,flush=True)
res=pd.DataFrame(rows);assert len(res)==144
for group,mainn,alln,maincol,allcol in [('MARS',33,88,'BH_q_primary_MARS_33','BH_q_all_MARS_88'),('bMIS',6,16,'BH_q_bMIS_primary6','BH_q_bMIS_all16')]:
 a=res.score_group.eq(group);p=a&res.is_primary_slice;assert a.sum()==alln and p.sum()==mainn
 res.loc[a,allcol]=stats.false_discovery_control(res.loc[a,'p_two_sided']);res.loc[p,maincol]=stats.false_discovery_control(res.loc[p,'p_two_sided'])
for ds,features,col in [('PROgECT',F[:3],'BH_q_primary_PROgECT_3'),('PROgECT',F[3:],'BH_q_primary_2'),('UNIFI_UST',F,'BH_q_primary_5')]:
 k=res.dataset.eq(ds)&res.is_primary_slice&res.feature.isin(features);assert k.sum()==len(features);res.loc[k,col]=stats.false_discovery_control(res.loc[k,'p_two_sided'])
res.to_csv(T/'outcomes144.csv',index=False);pd.DataFrame(long).to_csv(T/'patient_scores_and_outcomes.csv',index=False)
pd.DataFrame(pairs).to_csv(T/'paired_AUC261.csv',index=False);pd.DataFrame(sens).to_csv(T/'reference_sensitivity26.csv',index=False)

cor=[];structure=[]
for co,ref in [('UNIFI_all_UC','UNIFI_all_UC'),('PROgECT','PROgECT'),('PURSUIT_GOL','PURSUIT_all')]:
 ids=md[ref].index if co!='PURSUIT_GOL' else md[ref].index[md[ref].treatment.str.lower().eq('golimumab')]
 d=scores[ref].loc[ids,ALL].sort_index();sp=d.corr(method='spearman');sp.to_csv(T/(co+'_correlation.csv'));rng=np.random.default_rng(SEED);ix=rng.integers(0,len(d),(NB,len(d)))
 bb=np.empty((NB,18,18));arr=d.to_numpy()
 for start in range(0,NB,64):
  end=min(start+64,NB);rk=stats.rankdata(arr[ix[start:end]],axis=1);z=(rk-rk.mean(axis=1,keepdims=True))/rk.std(axis=1,ddof=1,keepdims=True);bb[start:end]=np.einsum('bni,bnj->bij',z,z)/(len(d)-1)
 for i,j in itertools.combinations(range(18),2):
  low,high=np.quantile(bb[:,i,j],[.025,.975]);cor.append({'cohort':co,'n':len(d),'score1':ALL[i],'score2':ALL[j],'rho':sp.iloc[i,j],'CI_low':low,'CI_high':high})
 e=np.linalg.eigvalsh(sp.loc[F,F])[::-1];structure.append({'cohort':co,'n':len(d),'median_pair_rho':np.median([sp.loc[a,b] for a,b in itertools.combinations(F,2)]),'rank_PC1_fraction':e[0]/e.sum()})
 print('CORRELATION_DONE',co,flush=True)
pd.DataFrame(cor).to_csv(T/'correlations459.csv',index=False);pd.DataFrame(structure).to_csv(T/'rank_structure.csv',index=False)
u=md['UNIFI_all_UC'];fields={'Mayo':'Field[Mayo_score]','CRP':'Field[CRP]','Fcal':'Field[Calprotectin]','Neutrophils_LP':'Field[Neutrophils_LP]','Neutrophils_Epithelium':'Field[Neutrophils_Epithelium]'}
cr=[]
for f in ALL:
 for measure,col in fields.items():
  v=pd.to_numeric(u[col],errors='coerce');ok=v.notna();z=stats.spearmanr(scores['UNIFI_all_UC'].loc[v.index[ok],f],v[ok]);cr.append({'feature':f,'measure':measure,'n':int(ok.sum()),'rho':z.statistic,'p_two_sided':z.pvalue,'score_group':'original5' if f in F else 'bMIS' if f in BM else 'MARS'})
cr=pd.DataFrame(cr)
for g in cr.score_group.unique():
 k=cr.score_group.eq(g);cr.loc[k,'BH_within_family']=stats.false_discovery_control(cr.loc[k,'p_two_sided'])
cr.to_csv(T/'clinical_correlations90.csv',index=False)

u=u[u.treatment.str.startswith('Ustekinumab')].copy();d=pd.DataFrame(index=u.index);d.index.name='patient_id'
d['gsm']=u['gsm'] if 'gsm' in u else pd.read_csv(O/'data/UNIFI_all_UC_metadata.csv').set_index('patient_id')['gsm'].loc[u.index]
d['nonremission']=u['clinical remission at week 8'].eq('N').astype(int);d['UST']=1;d['Mayo']=pd.to_numeric(u['Field[Mayo_score]']);d['antiTNF']=u['Field[Anti_TNF_history]'].map({'Y':1,'N':0});d['dose_body']=(~u.treatment.eq('Ustekinumab 130 mg IV')).astype(int)
d['logCRP']=np.log1p(pd.to_numeric(u['Field[CRP]'],errors='coerce'));d['logDuration']=np.log1p(pd.to_numeric(u['Field[Disease_duration]'],errors='coerce'));d['treatment_original']=u.treatment
for f in F+BM:
 x=scores['UNIFI_all_UC'].loc[d.index,f];d[f]=(x-x.mean())/x.std(ddof=1)
assert len(d)==364 and sum(d.nonremission==0)==49 and d.dose_body.sum()==184
cc=d.dropna(subset=['logCRP','logDuration']);assert len(cc)==360 and sum(cc.nonremission==0)==48
ref=d.copy();sub=pd.read_csv(O/'scores/UNIFI_UST_only_scores.csv',index_col=0)
for f in BM:
 x=sub.loc[d.index,f];ref[f]=(x-x.mean())/x.std(ddof=1)
d.to_csv(R/'main364.csv');cc.to_csv(R/'complete360.csv');ref.to_csv(R/'UST_reference364.csv')
mf=[]
def add(spec,kind,score='',bmis='',null_id=''):
 cid='__'.join([spec,kind,score or 'none',bmis or 'none']);v=(['score'] if score else [])+(['bmis'] if bmis else [])+['Mayo','antiTNF','dose_body']+(['logCRP','logDuration'] if spec=='extended360' else [])
 mf.append({'model_id':cid,'specification':spec,'kind':kind,'score_name':score,'bmis_name':bmis,'input_file':{'main364':'main364.csv','minimal360':'complete360.csv','extended360':'complete360.csv','UST_reference364':'UST_reference364.csv'}[spec],'variables':';'.join(v),'null_id':null_id});return cid
for s in ['main364','minimal360','extended360']:
 clin=add(s,'clinical')
 for f in F:add(s,'score_clinical',f,null_id=clin)
 for b in BM:
  null=add(s,'bmis_clinical',bmis=b,null_id=clin)
  for f in F:add(s,'joint',f,b,null)
for b in BM:
 null=add('UST_reference364','bmis_clinical',bmis=b)
 for f in F:add('UST_reference364','joint',f,b,null)
assert len(mf)==66;pd.DataFrame(mf).to_csv(R/'model_manifest.csv',index=False)
js(O/'statistics_complete.json',{'outcomes':144,'correlation_pairs':459,'clinical_pairs':90,'regression_manifest':66,'patients':721})
