import gzip,json,gc,time
import numpy as np,pandas as pd,gseapy
from scipy import special
from common import *
runtime('scores');D=O/'data';S=O/'scores';D.mkdir(exist_ok=True);S.mkdir(exist_ok=True)
ann=pd.read_csv(inp('input/annotation/unique_symbol_map.csv'))
ann68=pd.read_csv(inp('input/annotation/strict68_probe_map.csv'))
g68=inp('input/recipes/strict68.txt').read_text().split()
lm=pd.read_csv(inp('input/recipes/logOR40.csv'))
mods=pd.read_csv(inp('input/recipes/Friedrich_module_map.csv.gz'))
mars=json.loads(inp('input/recipes/MARS_v7.4.json').read_text(encoding='utf-8'))
ident=pd.read_csv(inp('input/recipes/MARS_identity.csv'));signs=ident.set_index('v7.4集合名')['原表与RHI相关'].apply(np.sign)
bmis=json.loads(inp('input/recipes/bMIS_UC498.json').read_text(encoding='utf-8'))['bMIS_UC']
sets={**mars,**{k:lm.loc[lm['class'].eq(k),'gene'].tolist() for k in ['Responsive','Nonresponsive']},'bMIS_UC':bmis}
assert len(g68)==68 and len(mars)==11 and len(bmis)==498

def read_expression(path):
 with gzip.open(path,'rt') as f:
  for line in f:
   if line.startswith('!series_matrix_table_begin'):break
  d=pd.read_csv(f,sep='\t',index_col=0,comment='!')
 d.index=d.index.astype(str);d.columns=d.columns.astype(str)
 assert d.index.is_unique and d.columns.is_unique and np.isfinite(d.to_numpy()).all()
 return d
def matrices(raw,pm):
 keys=pd.DataFrame({'probe_raw':raw.index});keys['probe']=keys.probe_raw.str.replace('_PM_','_',regex=False) if pm else keys.probe_raw
 assert keys.probe.is_unique
 m=keys.merge(ann,on='probe',validate='one_to_one');gm=raw.loc[m.probe_raw].copy();gm.index=m.gene;gm=gm.groupby(level=0,sort=True).mean()
 m68=keys.merge(ann68.rename(columns={'ID_REF':'probe'}),on='probe',validate='one_to_one');m68=m68[m68.SYMBOL.isin(g68)]
 q=raw.loc[m68.probe_raw].copy();q.index=m68.SYMBOL;q=q.groupby(level=0,sort=True).mean().loc[g68]
 assert len(q)==68
 return gm,q
def pc(x):
 x=x.to_numpy();z=(x-x.mean(axis=1,keepdims=True))/x.std(axis=1,ddof=1,keepdims=True)
 _,_,vh=np.linalg.svd(z,full_matrices=False);s=vh[0]
 return -s if np.corrcoef(s,z.mean(axis=0))[0,1]<0 else s
def formula(expr,gsets,ix):
 x=expr.to_numpy(dtype=float);p,n=x.shape;table=special.ndtr(np.arange(10001)/1000.);bw=x.std(axis=1,ddof=1)/4.;density=np.empty((p,len(ix)))
 for start in range(0,p,8):
  end=min(start+8,p);z=(x[start:end,ix,None]-x[start:end,None,:])/bw[start:end,None,None]
  j=np.minimum((abs(z)*1000).astype(np.int64),10000);cdf=table[j];cdf=np.where(z<0,1-cdf,cdf);cdf=np.where(z>10,1,np.where(z< -10,0,cdf))
  q=np.cumsum(cdf,axis=2)[:,:,-1]/n;density[start:end]=-np.log((1-q)/q)
 weights=abs(np.arange(p,0,-1,dtype=float)-p/2.);out={k:np.zeros(len(ix)) for k in gsets}
 for j in range(len(ix)):
  order=np.argsort(-density[:,j],kind='stable');genes=expr.index.to_numpy()[order]
  for k,gs in gsets.items():
   hit=np.isin(genes,gs);m=int(hit.sum());step=np.full(p,-1/(p-m));step[hit]=weights[hit]/weights[hit].sum();walk=np.cumsum(step)
   out[k][j]=max(0.,float(walk.max()))+min(0.,float(walk.min()))
 return pd.DataFrame(out,index=expr.columns[ix])

coverage=[];checks=[];start=time.time()
for co,acc,metafile in [('UNIFI_all_UC','GSE206285','UNIFI_clinical.csv'),('PROgECT','GSE212849','PROgECT_samples.csv'),('PURSUIT_all','GSE92415','PURSUIT_samples.csv')]:
 raw=read_expression(inp('input/expression/'+acc+'.txt.gz'))
 md=pd.read_csv(inp('input/metadata/'+metafile),keep_default_na=False).set_index('gsm')
 if co=='PURSUIT_all':md=md[md.visit.eq('Week 0')]
 selected=[g for g in raw.columns if g in md.index];raw=raw.loc[:,selected];md=md.loc[selected]
 assert len(selected)=={'UNIFI_all_UC':550,'PROgECT':84,'PURSUIT_all':87}[co]
 ids=md['subject'] if co=='PURSUIT_all' else md['donor id'];assert ids.is_unique
 md['patient_id']=ids;md.to_csv(D/(co+'_metadata.csv'))
 gm,q68=matrices(raw,co!='PROgECT');del raw;gc.collect()
 refs=[(co,gm.columns)]
 if co=='UNIFI_all_UC':refs.append(('UNIFI_UST_only',md.index[md.treatment.str.startswith('Ustekinumab')]))
 if co=='PURSUIT_all':refs.append(('PURSUIT_GOL_only',md.index[md.treatment.str.lower().eq('golimumab')]))
 for ref,cols in refs:
  x=gm.loc[:,cols];x=x.loc[x.std(axis=1,ddof=1)>1e-12].sort_index();actual={k:[g for g in gs if g in x.index] for k,gs in sets.items()}
  print('SCORING',ref,x.shape,flush=True)
  obj=gseapy.gsva(data=x.iloc[::-1].copy(),gene_sets=actual,outdir=None,kcdf='Gaussian',weight=1.,mx_diff=True,abs_rnk=False,min_size=1,max_size=len(x),threads=2,seed=SEED,verbose=False)
  es=obj.res2d.pivot(index='Name',columns='Term',values='ES').astype(float).loc[x.columns,list(sets)]
  z=x.loc[actual['bMIS_UC']].to_numpy();cz=((z-z.mean(axis=1,keepdims=True))/z.std(axis=1,ddof=1,keepdims=True)).sum(axis=0)/np.sqrt(len(z))
  d=es[list(mars)].mul(signs,axis=1);d[BM[0]]=cz;d[BM[1]]=es.bMIS_UC
  if ref==co:
   z=q68.loc[:,cols].to_numpy();d['strict68_mean']=((z-z.mean(axis=1,keepdims=True))/z.std(axis=1,ddof=1,keepdims=True)).mean(axis=0)
   d['OSM_mean']=x.loc['OSM'];d['negative_logOR']=-(es.Responsive+1)/(es.Nonresponsive+1)
   # The frozen logOR workflow groups patients with sort=True before GSVA.
   # Its density accumulation order differs from native GEO order in PURSUIT.
   # Preserve that recipe instead of loosening the raw-score acceptance gate.
   logcols=md.loc[cols].sort_values('patient_id').index
   if list(logcols)!=list(cols):
    lx=x.loc[:,logcols];lsets={k:actual[k] for k in ['Responsive','Nonresponsive']}
    le=gseapy.gsva(data=lx.iloc[::-1].copy(),gene_sets=lsets,outdir=None,kcdf='Gaussian',weight=1.,mx_diff=True,abs_rnk=False,min_size=1,max_size=len(lx),threads=2,seed=20261029,verbose=False).res2d.pivot(index='Name',columns='Term',values='ES').astype(float).loc[logcols]
    d['negative_logOR']=(-(le.Responsive+1)/(le.Nonresponsive+1)).reindex(d.index)
    lr=formula(lx,lsets,np.arange(len(logcols)));ld=float(abs(le[lr.columns]-lr).to_numpy().max());assert ld<1e-8
    checks.append({'reference':ref+'_logOR_patient_sorted','fixed_targets':len(logcols),'gene_sets':2,'max_abs_error':ld,'pass':True})
   for m in ['M4','M5']:
    genes=mods.loc[mods.moduleColor.eq(m),'geneName'].dropna().unique().tolist()
    if co!='UNIFI_all_UC':genes=sorted(set(genes))
    d[m]=pc(x.loc[[g for g in genes if g in x.index]])
   d=d[F+list(mars)+BM]
  d.index=md.loc[cols,'patient_id'].to_numpy();d.index.name='patient_id';d.to_csv(S/(ref+'_scores.csv'))
  ix=np.linspace(0,len(cols)-1,12,dtype=int);calc=formula(x,actual,ix);err=float(abs(es.loc[calc.index,calc.columns]-calc).to_numpy().max())
  assert err<1e-8,(ref,err);checks.append({'reference':ref,'fixed_targets':12,'gene_sets':14,'max_abs_error':err,'pass':True})
  for k,gs in sets.items():coverage.append({'reference':ref,'feature':k,'background_genes':len(x),'original_n':len(gs),'actual_n':len(actual[k]),'missing':';'.join(g for g in gs if g not in x.index)})
  print('SCORE_PASS',ref,err,'seconds',round(time.time()-start),flush=True)
 del gm,q68;gc.collect()
pd.DataFrame(coverage).to_csv(O/'coverage.csv',index=False);js(O/'GSVA_formula_checks.json',checks)
js(O/'scores_complete.json',{'references':5,'native_patients':721,'main_readouts':18,'formula_checks':sum(z['fixed_targets']*z['gene_sets'] for z in checks),'all_pass':True})
