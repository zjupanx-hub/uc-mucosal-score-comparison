Sys.setlocale('LC_ALL','English_United States.utf8')
options(stringsAsFactors=FALSE)
B<-normalizePath(commandArgs(trailingOnly=TRUE)[1],winslash='/',mustWork=TRUE)
I<-file.path(B,'output','regression_inputs');T<-file.path(B,'output','regression');dir.create(T,showWarnings=FALSE)
mf<-read.csv(file.path(I,'model_manifest.csv'),check.names=FALSE,na.strings='')
mf[is.na(mf)]<-''
F<-c('strict68_mean','negative_logOR','OSM_mean','M4','M5')
BM<-c('bMIS_UC_combinedZ','bMIS_UC_GSVA')
make_data<-function(r){
 d<-read.csv(file.path(I,r$input_file),check.names=FALSE)
 if(nzchar(r$score_name))d$score<-d[[r$score_name]]
 if(nzchar(r$bmis_name))d$bmis<-d[[r$bmis_name]]
 d
}
fit_one<-function(d,v){
 warn<-character()
 fit<-withCallingHandlers(glm(reformulate(v,response='nonremission'),data=d,family=binomial(),control=glm.control(epsilon=1e-14,maxit=100)),warning=function(w){warn<<-c(warn,conditionMessage(w));invokeRestart('muffleWarning')})
 tab<-coef(summary(fit)); pr<-fitted(fit)
 valid<-isTRUE(fit$converged)&&!isTRUE(fit$boundary)&&fit$rank==ncol(model.matrix(fit))&&all(is.finite(tab))&&all(pr>1e-8&pr<1-1e-8)
 list(fit=fit,valid=valid,warnings=paste(warn,collapse=' | '))
}
models<-list();out<-list();coefs<-list();diag<-list()
for(i in seq_len(nrow(mf))){
 r<-mf[i,];d<-make_data(r);v<-strsplit(r$variables,';',fixed=TRUE)[[1]]
 a<-fit_one(d,v);fit<-a$fit;models[[r$model_id]]<-a
 tab<-coef(summary(fit));target<-if(nzchar(r$score_name))'score' else if(nzchar(r$bmis_name))'bmis' else 'Mayo'
 z<-tab[target,];pr<-fitted(fit)
 out[[i]]<-data.frame(model_id=r$model_id,specification=r$specification,kind=r$kind,score_name=r$score_name,bmis_name=r$bmis_name,n=nrow(d),remission_n=sum(d$nonremission==0),target=target,beta=z[1],SE=z[2],OR=exp(z[1]),OR_low=exp(z[1]-qnorm(.975)*z[2]),OR_high=exp(z[1]+qnorm(.975)*z[2]),p_Wald=z[4],logLik=as.numeric(logLik(fit)),rank=fit$rank,parameters=ncol(model.matrix(fit)),converged=fit$converged,valid=a$valid,min_probability=min(pr),max_probability=max(pr),max_Cook=max(cooks.distance(fit)),warnings=a$warnings)
 coefs[[i]]<-data.frame(model_id=r$model_id,term=rownames(tab),beta=tab[,1],SE=tab[,2],p=tab[,4])
 if(r$kind=='joint'){
  X<-model.matrix(fit)[,-1,drop=FALSE]
  vif<-function(term){y<-X[,term];xx<-cbind(1,X[,colnames(X)!=term,drop=FALSE]);resid<-lm.fit(xx,y)$residuals;sum((y-mean(y))^2)/sum(resid^2)}
  cx<-scale(X);sv<-svd(cx,nu=0,nv=0)$d
  diag[[length(diag)+1]]<-data.frame(model_id=r$model_id,specification=r$specification,score_name=r$score_name,bmis_name=r$bmis_name,VIF_score=vif('score'),VIF_bmis=vif('bmis'),condition_number=max(sv)/min(sv),Pearson=cor(d$score,d$bmis),Spearman=cor(d$score,d$bmis,method='spearman'),max_leverage=max(hatvalues(fit)))
 }
}
res<-do.call(rbind,out);allcoef<-do.call(rbind,coefs)
res$LR_chisq<-NA_real_;res$p_LR<-NA_real_
for(i in which(mf$kind=='joint')){
 r<-mf[i,];j<-match(r$null_id,res$model_id);stat<-2*(res$logLik[i]-res$logLik[j]);stopifnot(stat>=-1e-8)
 res$LR_chisq[i]<-max(0,stat);res$p_LR[i]<-pchisq(max(0,stat),df=1,lower.tail=FALSE)
}
res$BH_Wald_10<-NA_real_;res$BH_LR_10<-NA_real_;res$BH_Wald_40<-NA_real_
for(s in unique(mf$specification)){
 k<-res$kind=='joint'&res$specification==s
 stopifnot(sum(k)==10)
 res$BH_Wald_10[k]<-p.adjust(res$p_Wald[k],'BH');res$BH_LR_10[k]<-p.adjust(res$p_LR[k],'BH')
}
k<-res$kind=='joint';res$BH_Wald_40[k]<-p.adjust(res$p_Wald[k],'BH')
write.csv(res,file.path(T,'全部66模型.csv'),row.names=FALSE)
write.csv(allcoef,file.path(T,'全部回归系数.csv'),row.names=FALSE)
write.csv(do.call(rbind,diag),file.path(T,'40联合模型诊断.csv'),row.names=FALSE)
stopifnot(all(res$valid))
cat('DETERMINISTIC_COMPLETE models=',nrow(res),' all_valid=',all(res$valid),'\n');flush.console()
print(res[res$specification=='main364'&res$kind=='joint',c('score_name','bmis_name','OR','OR_low','OR_high','p_Wald','BH_Wald_10','BH_LR_10')])

# Fixed-sample scale is retained in each refit; shared draws preserve pairing.
d<-read.csv(file.path(I,'main364.csv'),check.names=FALSE)
set.seed(20261030);NB<-2000L
idx<-t(replicate(NB,c(sample(which(d$nonremission==0),sum(d$nonremission==0),replace=TRUE),sample(which(d$nonremission==1),sum(d$nonremission==1),replace=TRUE))))
write.csv(idx[1:8,,drop=FALSE],file.path(I,'bootstrap_first8_indices_1based.csv'),row.names=FALSE)
write.csv(idx,file.path(I,'bootstrap_all2000_indices_1based.csv'),row.names=FALSE)
bootmf<-mf[mf$specification=='main364'&mf$kind%in%c('score_clinical','joint'),]
br<-vector('list',NB*nrow(bootmf));q<-0L
for(k in seq_len(NB)){
 dd<-d[idx[k,],,drop=FALSE]
 for(j in seq_len(nrow(bootmf))){
  r<-bootmf[j,];dd$score<-dd[[r$score_name]]
  if(nzchar(r$bmis_name))dd$bmis<-dd[[r$bmis_name]]
  v<-strsplit(r$variables,';',fixed=TRUE)[[1]];a<-tryCatch(fit_one(dd,v),error=function(e)list(valid=FALSE,warnings=conditionMessage(e)))
  q<-q+1L
  if(!is.null(a$fit)){
   z<-coef(summary(a$fit))['score',];br[[q]]<-data.frame(draw=k,model_id=r$model_id,beta=z[1],SE=z[2],valid=a$valid,warnings=a$warnings)
  }else br[[q]]<-data.frame(draw=k,model_id=r$model_id,beta=NA_real_,SE=NA_real_,valid=FALSE,warnings=a$warnings)
 }
 if(k%%100L==0L){cat('BOOTSTRAP',k,'/',NB,'\n');flush.console()}
}
boot<-do.call(rbind,br);write.csv(boot,file.path(T,'bootstrap全部30000次拟合.csv'),row.names=FALSE)
cat('BOOTSTRAP_COMPLETE valid=',sum(boot$valid),'/',nrow(boot),'\n');flush.console()

lmf<-mf[mf$specification=='main364'&mf$kind=='joint',]
lr<-vector('list',nrow(d)*nrow(lmf));q<-0L
for(k in seq_len(nrow(d))){
 dd<-d[-k,,drop=FALSE]
 for(j in seq_len(nrow(lmf))){
  r<-lmf[j,];dd$score<-dd[[r$score_name]];dd$bmis<-dd[[r$bmis_name]]
  a<-tryCatch(fit_one(dd,strsplit(r$variables,';',fixed=TRUE)[[1]]),error=function(e)list(valid=FALSE,warnings=conditionMessage(e)))
  q<-q+1L
  if(!is.null(a$fit)){
   z<-coef(summary(a$fit))['score',];lr[[q]]<-data.frame(omitted_patient=d$patient_id[k],model_id=r$model_id,beta=z[1],SE=z[2],valid=a$valid,warnings=a$warnings)
  }else lr[[q]]<-data.frame(omitted_patient=d$patient_id[k],model_id=r$model_id,beta=NA_real_,SE=NA_real_,valid=FALSE,warnings=a$warnings)
 }
 if(k%%100L==0L){cat('LEAVE_ONE_OUT',k,'/',nrow(d),'\n');flush.console()}
}
loo<-do.call(rbind,lr);write.csv(loo,file.path(T,'留一患者全部3640次拟合.csv'),row.names=FALSE)
capture.output(sessionInfo(),file=file.path(B,'R运行环境.txt'))
cat('ALL_R_COMPLETE bootstrap_invalid=',sum(!boot$valid),' loo_invalid=',sum(!loo$valid),'\n')
