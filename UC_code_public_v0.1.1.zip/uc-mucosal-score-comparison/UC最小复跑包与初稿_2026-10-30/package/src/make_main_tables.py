"""Export the two manuscript working tables from newly computed outputs."""
import pandas as pd
import numpy as np
from common import O

def export_main_tables():
 r=pd.read_csv(O/'tables/outcomes144.csv')
 q=pd.read_csv(O/'regression/全部66模型.csv')
 br=pd.read_csv(O/'regression/bootstrap全部30000次拟合.csv')
 table=[]
 for trial,ds,ref,n,ep in [('UNIFI','UNIFI_UST',550,364,'W8临床缓解'),('PROgECT','PROgECT',84,84,'W6临床缓解'),('PURSUIT','PURSUIT_GOL',87,59,'W6临床应答')]:
  a=r[r.dataset.eq(ds)&r.is_primary_slice]
  table.append({'试验':trial,'基线参照人数':ref,'主要用药人数':n,'有利结局人数':int(a.response_n.iloc[0]),'原主要结局':ep,'原五评分AUC范围':f"{a[a.score_group.eq('original5')].AUC.min():.3f}–{a[a.score_group.eq('original5')].AUC.max():.3f}",'MARS主要通过数':int((a.BH_q_primary_MARS_33<.05).sum()),'bMIS主要通过数':int((a.BH_q_bMIS_primary6<.05).sum())})
 pd.DataFrame(table).to_csv(O/'tables/Table1_cohort_and_main_results.csv',index=False,encoding='utf-8-sig')
 rows=[]
 for z in q[q.specification.eq('main364')&q.kind.eq('joint')].itertuples(index=False):
  b=br[br.model_id.eq(z.model_id)&br.valid]
  lo,hi=np.exp(np.quantile(b.beta,[.025,.975]))
  rows.append({'评分':z.score_name,'bMIS实现':z.bmis_name,'OR':z.OR,'Wald_low':z.OR_low,'Wald_high':z.OR_high,'BH10_q':z.BH_Wald_10,'bootstrap_low':lo,'bootstrap_high':hi})
 pd.DataFrame(rows).to_csv(O/'tables/Table2_main_conditional_associations.csv',index=False,encoding='utf-8-sig')
