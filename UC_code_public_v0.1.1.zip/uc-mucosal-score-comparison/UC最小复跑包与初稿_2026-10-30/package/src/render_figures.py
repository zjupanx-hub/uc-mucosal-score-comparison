import json
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch
from common import *
runtime('figures');G=O/'figures';G.mkdir(exist_ok=True);T=O/'tables'
plt.rcParams.update({'font.family':'Arial','font.size':10,'svg.fonttype':'none','pdf.fonttype':42})
M=list(json.loads(inp('input/recipes/MARS_v7.4.json').read_text(encoding='utf-8')))
names=dict(zip(F,['68 genes','logOR40 reversed','OSM','M4','M5']))
names.update(dict(zip(M,['IFNa','IL4/IL13','Platelet/collagen','SARS pathway','Tryptophan','UPR','Asp/Asn','BCAA','FZD','Sulfur AA','Peroxisome'])))
names.update({BM[0]:'bMIS Z',BM[1]:'bMIS GSVA'})
def save(fig,num):
 for ext in ['png','pdf','svg']:fig.savefig(G/f'Figure{num}.{ext}',dpi=200)
 plt.close(fig)
captions={}
fig,ax=plt.subplots(figsize=(10.5,4.8));ax.set_axis_off();ax.set_xlim(0,1);ax.set_ylim(0,1)
for j,(trial,n,treated,ep) in enumerate([('UNIFI',550,364,'W8 remission: 49'),('PROgECT',84,84,'W6 remission: 11'),('PURSUIT',87,59,'W6 response: 32')]):
 x=.03+j*.33
 for y,text in [(.69,f'{trial}\nReference patients: {n}'),(.38,f'Main treated patients: {treated}\n{ep}'),(.08,'Five original + 11 MARS\n+ two bMIS implementations')]:
  ax.add_patch(FancyBboxPatch((x,y),.28,.20,boxstyle='round,pad=0.015',facecolor='#eef5f9',edgecolor='#5284a0'))
  ax.text(x+.14,y+.1,text,ha='center',va='center',fontsize=10)
 ax.annotate('',xy=(x+.14,.60),xytext=(x+.14,.68),arrowprops={'arrowstyle':'->','color':'#555555'})
 ax.annotate('',xy=(x+.14,.30),xytext=(x+.14,.37),arrowprops={'arrowstyle':'->','color':'#555555'})
fig.subplots_adjust(left=.02,right=.98,bottom=.04,top=.98);save(fig,1)
captions['Figure1']='Three trials, 721 distinct baseline patients; main treated analyses use 507 patients with trial-specific outcomes. Counts by analysis use overlap; score-specific original/reanalysis roles are curated in input/context. Two bMIS algorithms share one biological panel.'

fig,axs=plt.subplots(1,3,figsize=(17,6.8))
cols=F+M+BM
for ax,co in zip(axs,['UNIFI_all_UC','PROgECT','PURSUIT_GOL']):
 d=pd.read_csv(T/(co+'_correlation.csv'),index_col=0).loc[cols,cols]
 im=ax.imshow(d,cmap='RdBu_r',vmin=-1,vmax=1)
 ax.set_xticks(range(18),[names[f] for f in cols],rotation=65,ha='right',fontsize=7.7);ax.set_yticks(range(18),[names[f] for f in cols],fontsize=7.7)
 ax.set_title(co.replace('_',' '),fontsize=10);ax.tick_params(length=0)
fig.subplots_adjust(left=.07,right=.94,bottom=.24,top=.95,wspace=.4);cax=fig.add_axes([.96,.30,.012,.48]);fig.colorbar(im,cax=cax,label='Spearman rho');save(fig,2)
captions['Figure2']='Patient-level Spearman matrices of the 18 continuous readouts; UNIFI550, PROgECT84 and PURSUIT GOL59. Diverging scale retains negative values. Same patients contribute to multiple scores; no independent-replication count is inferred.'

r=pd.read_csv(T/'outcomes144.csv');sel=F+BM
fig,axs=plt.subplots(1,3,figsize=(12,5.5),sharey=True)
for ax,co in zip(axs,['PURSUIT_GOL','PROgECT','UNIFI_UST']):
 d=r[r.dataset.eq(co)&r.is_primary_slice].set_index('feature').loc[sel]
 for i,f in enumerate(sel):
  z=d.loc[f];c='#444444' if f in F else '#0072B2';ax.errorbar(z.AUC,i,xerr=[[z.AUC-z.AUC_low],[z.AUC_high-z.AUC]],fmt='o',ms=4.5,color=c,capsize=3)
 ax.axvline(.5,color='#999999',ls='--',lw=.8);ax.set_xlim(.25,.95);ax.set_xticks([.3,.5,.7,.9]);ax.set_xlabel('AUC: unfavorable outcome');ax.set_title(co.replace('_',' '),fontsize=11);ax.grid(axis='x',color='#eeeeee');ax.spines[['top','right']].set_visible(False)
axs[0].set_yticks(range(7),[names[f] for f in sel]);axs[0].invert_yaxis();fig.subplots_adjust(left=.17,right=.98,bottom=.16,top=.9,wspace=.17);save(fig,3)
captions['Figure3']='Main original endpoints shown separately: PURSUIT GOL W6 response59/32 favorable, PROgECT GOL W6 remission84/11, UNIFI UST W8 remission364/49. Fixed adverse direction; 2000 stratified-patient pointwise bootstrap intervals. Full MARS and all 144 results are in SourceData.'

reg=pd.read_csv(O/'regression/全部66模型.csv');q=reg[reg.specification.eq('main364')];base=q[q.kind.eq('score_clinical')].set_index('score_name');joint=q[q.kind.eq('joint')]
boot=pd.read_csv(O/'regression/bootstrap全部30000次拟合.csv')
fig,(ax,ax2)=plt.subplots(1,2,figsize=(13,6.2))
groups=[('Score + clinical',base,'#555555'),('+ bMIS Z',joint[joint.bmis_name.eq(BM[0])].set_index('score_name'),'#0072B2'),('+ bMIS GSVA',joint[joint.bmis_name.eq(BM[1])].set_index('score_name'),'#D55E00')]
for j,(label,d,c) in enumerate(groups):
 for i,f in enumerate(F):
  z=d.loc[f];ax.errorbar(z.OR,i+(j-1)*.20,xerr=[[z.OR-z.OR_low],[z.OR_high-z.OR]],fmt='o',ms=4,color=c,capsize=2.5)
ax.set_yticks(range(5),[names[f] for f in F]);ax.invert_yaxis();ax.set_xlabel('Adjusted OR per score SD')
labels=[];k=0
for f in F:
 for b,c in zip(BM,['#0072B2','#D55E00']):
  z=joint[joint.score_name.eq(f)&joint.bmis_name.eq(b)].iloc[0];d=boot[boot.model_id.eq(z.model_id)&boot.valid];lo,hi=np.exp(np.quantile(d.beta,[.025,.975]))
  ax2.errorbar(z.OR,k-.10,xerr=[[z.OR-z.OR_low],[z.OR_high-z.OR]],fmt='o',ms=4,color=c,capsize=2)
  ax2.errorbar(z.OR,k+.10,xerr=[[z.OR-lo],[hi-z.OR]],fmt='D',mfc='white',ms=4,color=c,capsize=2)
  labels.append(names[f]+(' | Z' if b==BM[0] else ' | GSVA'));k+=1
ax2.set_yticks(range(10),labels,fontsize=9);ax2.invert_yaxis();ax2.set_xlabel('Conditional OR: Wald / bootstrap interval')
for a in [ax,ax2]:a.axvline(1,color='#999999',ls='--',lw=.8);a.set_xscale('log');a.set_xlim(.42,6);a.set_xticks([.5,1,2,4]);a.set_xticklabels(['0.5','1','2','4']);a.grid(axis='x',color='#eeeeee');a.spines[['top','right']].set_visible(False)
fig.legend(handles=[Line2D([0],[0],color=c,marker='o',label=l) for l,d,c in groups]+[Line2D([0],[0],color='#555555',marker='D',mfc='white',label='Pointwise bootstrap interval')],loc='lower center',ncol=2,frameon=False,fontsize=9)
fig.subplots_adjust(left=.10,right=.98,bottom=.18,top=.96,wspace=.62);save(fig,4)
captions['Figure4']='UNIFI UST364/49 remissions. Each score is modeled separately with Mayo, prior anti-TNF exposure and dose. Right panel adds one bMIS implementation, showing pointwise Wald and percentile-bootstrap intervals for all ten coefficients. Primary Wald BH10 has no passing result; M4 Wald/bootstrap differences remain visible. Bootstrap is internal stability, not external validation.'

pr=pd.read_csv(inp('input/technical/probe_rule_paired.csv'));mr=pd.read_csv(inp('input/technical/module_reference_paired.csv'));dd=pd.read_csv(inp('input/technical/patient_dedup_paired.csv'))
items=[]
for ds,label in [('GSE92415','68 probe choice | n=87'),('GSE92415_golimumab','68 probe choice | GOL59')]:
 z=pr[pr.dataset.eq(ds)&pr.comparison.eq('strict68:outcome_probe_to_mean')].iloc[0];items.append((label,z.delta_AUC,z.AUC_low,z.AUC_high))
for m in ['M4','M5']:
 z=mr[mr.dataset.eq('UC24')&mr.comparison.eq(m+':all133_to_baseline_only')].iloc[0];items.append((m+' reference | UC24',z.delta_AUC,z.AUC_low,z.AUC_high))
z=dd[dd.dataset.eq('GSE12251')].iloc[0];items.append(('Patient dedup | ACT1 22',z.delta_AUC,z.AUC_low,z.AUC_high))
ss=pd.read_csv(T/'reference_sensitivity26.csv');fig,(ax,ax2)=plt.subplots(1,2,figsize=(13.2,7.4))
for i,(label,est,lo,hi) in enumerate(items):ax.errorbar(est,i,xerr=[[est-lo],[hi-est]],fmt='o',color='#555555',capsize=3)
ax.set_yticks(range(len(items)),[a[0] for a in items]);ax.invert_yaxis();ax.set_xlabel('Paired delta AUC: supplied technical estimates')
for j,(co,c) in enumerate([('UNIFI_UST','#0072B2'),('PURSUIT_GOL','#D55E00')]):
 z=ss[ss.dataset.eq(co)].set_index('feature').loc[M+BM]
 for i,f in enumerate(M+BM):
  a=z.loc[f];ax2.errorbar(a.delta_AUC,i+(j-.5)*.18,xerr=[[a.delta_AUC-a.CI_low],[a.CI_high-a.delta_AUC]],fmt='o',ms=3.5,color=c,capsize=2)
ax2.set_yticks(range(13),[names[f] for f in M+BM],fontsize=9);ax2.invert_yaxis();ax2.set_xlabel('Paired delta AUC: subset minus full reference')
for a in [ax,ax2]:a.axvline(0,color='#999999',ls='--',lw=.8);a.grid(axis='x',color='#eeeeee');a.spines[['top','right']].set_visible(False)
fig.legend(handles=[Line2D([0],[0],color='#0072B2',marker='o',label='UNIFI UST'),Line2D([0],[0],color='#D55E00',marker='o',label='PURSUIT GOL')],loc='lower center',ncol=2,frameon=False)
fig.subplots_adjust(left=.20,right=.98,bottom=.12,top=.97,wspace=.65);save(fig,5)
captions['Figure5']='Left: supplied historical same-patient technical estimates, rendered from frozen input tables; their training/selection pipelines are NOT rerun in this package. Right: newly recomputed subset-reference sensitivity for all MARS and bMIS readouts. Pointwise paired bootstrap intervals; no universal optimism/collapse claim.'
(G/'captions.json').write_text(json.dumps(captions,ensure_ascii=False,indent=2),encoding='utf-8')
pd.DataFrame(items,columns=['case','delta_AUC','low','high']).to_csv(T/'Figure5_supplied_case_source.csv',index=False)
from make_main_tables import export_main_tables
export_main_tables()
js(O/'figures_complete.json',{'main_figures':5,'main_tables':2,'formats':['png','pdf','svg'],'role':'analysis drafts, not journal final artwork','historical_technical_panel_render_only':True})
print('FIVE_ANALYSIS_FIGURES_COMPLETE',flush=True)
