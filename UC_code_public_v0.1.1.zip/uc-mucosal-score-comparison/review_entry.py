from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys

def preflight(root):
    core=root/'UC最小复跑包与初稿_2026-10-30/package'
    pur=root/'UC_PURSUIT有限临床调整_2026-10-30'
    manifest=core/'input_manifest.json'
    if not manifest.is_file():
        raise SystemExit('Restore the core input kit; input_manifest.json is missing.')
    entries=json.loads(manifest.read_text(encoding='utf-8-sig'))
    missing=[];changed=[]
    for row in entries:
        target=(core/row['path']).resolve()
        if not target.is_relative_to(core.resolve()):
            raise SystemExit('Manifest path leaves the core directory.')
        if not target.is_file():missing.append(row['path']);continue
        digest=hashlib.sha256(target.read_bytes()).hexdigest()
        if digest!=row['sha256']:changed.append(row['path'])
    required=['准备患者及模型.py','计算有限调整.R','独立数值核对.py','汇总有限调整.py','固定分析方案.md','分析前冻结.json']
    missing_scripts=[name for name in required if not (pur/name).is_file()]
    result={'input_files':len(entries),'missing':missing,'checksum_mismatches':changed,'missing_PURSUIT_scripts':missing_scripts,'models_fitted':0,'pass':not(missing or changed or missing_scripts)}
    print(json.dumps(result,ensure_ascii=False),flush=True)
    if not result['pass']:raise SystemExit(2)
    return core,pur

def main():
    parser=argparse.ArgumentParser(description='Run the original fixed UC core and PURSUIT workflows; no score or model specifications are changed.')
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--mode',choices=['preflight','all','core','pursuit'],default='preflight')
    parser.add_argument('--rscript',default='Rscript')
    args=parser.parse_args();root=args.root.resolve()
    core,pur=preflight(root)
    if args.mode=='preflight':return
    if sys.prefix==sys.base_prefix:raise SystemExit('Use the exact core virtual environment before calculating models.')
    env=os.environ.copy()
    for key in ['PYTHONPATH','PYTHONHOME','OPENAI_API_KEY']:env.pop(key,None)
    if args.mode in ['all','core']:
        subprocess.run([sys.executable,'-I','-X','utf8',str(core/'run_pipeline.py'),'--stage','all','--rscript',args.rscript],cwd=root,env=env,check=True)
    if args.mode in ['all','pursuit']:
        commands=[
            [sys.executable,'-I','-X','utf8',str(pur/'准备患者及模型.py')],
            [args.rscript,'--vanilla',str(pur/'计算有限调整.R'),str(pur)],
            [sys.executable,'-I','-X','utf8',str(pur/'独立数值核对.py')],
            [sys.executable,'-I','-X','utf8',str(pur/'汇总有限调整.py')],
        ]
        for command in commands:subprocess.run(command,cwd=root,env=env,check=True)

if __name__=='__main__':main()
